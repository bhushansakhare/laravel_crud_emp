<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\empController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Routes for employee management
Route::get('/employees', [empController::class, 'index']);
Route::get('/employees/create', [empController::class, 'create']);
Route::post('/employees', [empController::class, 'store']);
Route::get('/employees/{id}', [empController::class, 'show']);
Route::get('/employees/{id}/edit', [empController::class, 'edit']);
Route::patch('/employees/{id}', [empController::class, 'update']);
Route::delete('/employees/{id}', [empController::class, 'destroy']);

