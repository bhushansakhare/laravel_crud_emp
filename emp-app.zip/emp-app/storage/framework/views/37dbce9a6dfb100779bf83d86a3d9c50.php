
<?php $__env->startSection('content'); ?>

<div class="card">
  <div class="card-header">Employee Details</div>
  <div class="card-body">
    <div class="card-body">
      <h5 class="card-title">Name: <?php echo e($employee->name); ?></h5>
      <p class="card-text">Address: <?php echo e($employee->address); ?></p>
      <p class="card-text">Mobile: <?php echo e($employee->mobile); ?></p>
    </div>
    <hr>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('employees.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hp\Desktop\laravel\emp-app\resources\views/employees/show.blade.php ENDPATH**/ ?>