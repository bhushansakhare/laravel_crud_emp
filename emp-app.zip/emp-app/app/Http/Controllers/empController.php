<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\employee;

class empController extends Controller
{
    public function index()
    {
        $employees = employee::all();
        return view('employees.index')->with('employees', $employees);
    }

    public function create()
    {
        return view('employees.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'mobile' => 'required|string|max:20',
        ]);

        $employee = new employee([
            'name' => $request->input('name'),
            'address' => $request->input('address'),
            'mobile' => $request->input('mobile'),
        ]);

        $employee->save();

        return redirect('/employees')->with('success', 'Employee created successfully');
    }

    public function show(string $id)
    {
        $employee = employee::find($id);
        return view('employees.show')->with('employee', $employee);
    }

    public function edit(string $id)
    {
        $employee = employee::find($id);
        return view('employees.edit')->with('employee', $employee);
    }

    public function update(Request $request, string $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'mobile' => 'required|string|max:20',
        ]);

        $employee = employee::find($id);
        $employee->update([
            'name' => $request->input('name'),
            'address' => $request->input('address'),
            'mobile' => $request->input('mobile'),
        ]);

        return redirect('/employees')->with('success', 'Employee updated successfully');
    }

    public function destroy(string $id)
    {
        try {
            // Find the employee by ID
            $employee = employee::findOrFail($id);

            // Delete the employee
            $employee->delete();

            return redirect('/employees')->with('success', 'Employee deleted successfully');
        } catch (\Exception $e) {
            return redirect('/employees')->with('error', 'Error deleting employee');
        }
    }
}
